(() => {
  'use strict';
  const canvas = document.getElementById('game-canvas');
  const ctx = canvas.getContext('2d');
  const $ = (id) => document.getElementById(id);
  const ui = {
    hud:$('hud'), menu:$('menu-overlay'), pause:$('pause-overlay'), result:$('result-overlay'), controls:$('mobile-controls'), footer:$('game-footer'),
    announcement:$('announcement'), announceKicker:$('announce-kicker'), announceTitle:$('announce-title'), announceLine:$('announce-line'),
    timer:$('timer'), roundNumber:$('round-number'), playerHealth:$('player-health'), cpuHealth:$('cpu-health'), playerHp:$('player-hp-text'), cpuHp:$('cpu-hp-text'),
    playerEnergy:$('player-energy'), cpuEnergy:$('cpu-energy'), playerEnergyText:$('player-energy-text'), cpuEnergyText:$('cpu-energy-text'), playerRounds:$('player-rounds'), cpuRounds:$('cpu-rounds'),
    trainingLabel:$('training-label'), portraitWarning:$('portrait-warning')
  };
  const W=1280,H=720, TAU=Math.PI*2;
  let cw=0,ch=0,dpr=1,viewScale=1,offX=0,offY=0,last=0,elapsed=0,mode='menu',training=false,muted=false,audioCtx=null,shake=0,flash=0,roundPause=0,gameTime=90,roundNum=1,playerWins=0,cpuWins=0,combo=0,comboTimer=0,announcerTimer=0,announceHold=0,matchWinner='';
  const held=new Set(),touchHeld=new Set(),effects=[],projectiles=[],particles=[];
  const keys={left:['ArrowLeft','a','A'],right:['ArrowRight','d','D'],up:['ArrowUp','w','W'],down:['ArrowDown','s','S'],jump:[' ','Space'],punch:['j','J'],kick:['k','K'],guard:['l','L'],aura:['i','I']};
  const camera={x:0,y:0};
  function fighter({name,x,z,color,aura,player}){return {name,x,z,color,aura,player,hp:100,maxHp:100,energy:player?35:22,vx:0,vy:0,jump:0,groundY:0,facing:player?1:-1,attack:null,guard:false,stun:0,invuln:0,flash:0,hitStop:0,aiThink:0,aiAction:0,aiLane:0,walk:0,ko:false,roundDamage:0,landSlam:false,superGlow:0,trail:[],lastAction:'',specialCooldown:0};}
  let p1=fighter({name:'VOLT',x:390,z:.16,color:'#eaf8ff',aura:'#39d8ff',player:true});
  let p2=fighter({name:'SHADE',x:890,z:-.12,color:'#ffeaf5',aura:'#ff4caa',player:false});
  function resize(){
    const rect=canvas.getBoundingClientRect(); cw=Math.max(1,rect.width);ch=Math.max(1,rect.height);dpr=Math.min(window.devicePixelRatio||1,2);
    canvas.width=Math.round(cw*dpr);canvas.height=Math.round(ch*dpr);viewScale=Math.min(cw/W,ch/H);offX=(cw-W*viewScale)/2;offY=(ch-H*viewScale)/2;
  }
  window.addEventListener('resize',resize,{passive:true});
  function seededNoise(n){const v=Math.sin(n*127.1+311.7)*43758.5453;return v-Math.floor(v);}
  function playTone(freq=180,duration=.08,type='sine',gain=.035){if(muted)return;try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.setValueAtTime(freq,audioCtx.currentTime);o.frequency.exponentialRampToValueAtTime(Math.max(35,freq*.48),audioCtx.currentTime+duration);g.gain.setValueAtTime(gain,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+duration);}catch(_){}}
  function announce(kicker,title,line,seconds=1.55){ui.announceKicker.textContent=kicker;ui.announceTitle.textContent=title;ui.announceLine.textContent=line;ui.announcement.hidden=false;announcerTimer=seconds;}
  function hideAnnouncement(){ui.announcement.hidden=true;}
  function initMatch(isTraining=false){
    training=isTraining;mode='playing';document.body.classList.add('in-game');ui.menu.hidden=true;ui.pause.hidden=true;ui.result.hidden=true;ui.hud.hidden=false;ui.controls.hidden=false;ui.footer.hidden=false;ui.trainingLabel.hidden=!training;
    p1=fighter({name:'VOLT',x:400,z:.1,color:'#eaf8ff',aura:'#39d8ff',player:true});p2=fighter({name:'SHADE',x:880,z:-.1,color:'#fff0f7',aura:'#ff4caa',player:false});
    gameTime=90;roundNum=1;playerWins=0;cpuWins=0;combo=0;comboTimer=0;effects.length=0;projectiles.length=0;particles.length=0;held.clear();touchHeld.clear();roundPause=0;shake=0;flash=0;matchWinner='';last=performance.now();ui.playerRounds.textContent='0';ui.cpuRounds.textContent='0';announce(training?'TRAINING SIMULATION':'FIRST TO TWO ROUNDS','READY?','FIND YOUR RANGE. MASTER YOUR AURA.',1.7);playTone(440,.08,'triangle',.02);requestLandscape();}
  function requestLandscape(){try{if(screen.orientation&&screen.orientation.lock)screen.orientation.lock('landscape').catch(()=>{});}catch(_){}}
  function toMenu(){mode='menu';document.body.classList.remove('in-game');ui.menu.hidden=false;ui.pause.hidden=true;ui.result.hidden=true;ui.hud.hidden=true;ui.controls.hidden=true;ui.footer.hidden=true;ui.announcement.hidden=true;held.clear();touchHeld.clear();}
  function pauseGame(){if(mode==='playing'){mode='paused';ui.pause.hidden=false;held.clear();touchHeld.clear();}else if(mode==='paused'){mode='playing';ui.pause.hidden=true;last=performance.now();}}
  function endMatch(winner){mode='result';matchWinner=winner;ui.result.hidden=false;ui.controls.hidden=true;ui.footer.hidden=true;ui.announceTitle.textContent=winner==='player'?'VICTORY':'DEFEAT';$('result-title').innerHTML=winner==='player'?'VICTORY<span>.</span>':'DEFEAT<span>.</span>'; $('result-kicker').textContent=training?'TRAINING COMPLETE':'MATCH COMPLETE';$('result-copy').textContent=winner==='player'?'You own this arena. Your aura speaks for itself.':'The arena has spoken. Reclaim your power and try again.';$('result-round-score').textContent=`${playerWins} — ${cpuWins}`;$('result-style').textContent=combo>=5?'COMBO ARTIST':(p1.energy>=65?'AURA MASTER':'WARRIOR');$('result-emblem').textContent=winner==='player'?'✦':'◈';playTone(winner==='player'?620:100,.32,'sawtooth',.045);}
  function nextRound(winner){if(winner==='player')playerWins++;else cpuWins++;ui.playerRounds.textContent=playerWins;ui.cpuRounds.textContent=cpuWins;roundPause=2.1;mode='roundbreak';if(!training&&(playerWins>=2||cpuWins>=2)){setTimeout(()=>endMatch(playerWins>=2?'player':'cpu'),1700);announce('MATCH DECIDED',playerWins>=2?'VICTORY':'DEFEAT',playerWins>=2?'THE ARENA BELONGS TO YOU':'SHADE TAKES THE MATCH',1.55);return;}const msg=winner==='player'?'ROUND WON':'ROUND LOST';announce(`ROUND ${String(roundNum).padStart(2,'0')}`,msg,winner==='player'?'KEEP THE PRESSURE ON':'ADAPT. FIND THE OPENING.',1.8);roundNum++;p1.hp=100;p2.hp=100;p1.energy=Math.max(25,p1.energy);p2.energy=Math.max(20,p2.energy);p1.x=400;p2.x=880;p1.z=.1;p2.z=-.1;p1.vx=p2.vx=p1.vy=p2.vy=0;p1.attack=p2.attack=null;p1.stun=p2.stun=0;p1.ko=p2.ko=false;p1.roundDone=p2.roundDone=false;p1.fallY=p2.fallY=0;p1.airY=p2.airY=0;p1.yVel=p2.yVel=0;gameTime=90;ui.roundNumber.textContent=String(roundNum).padStart(2,'0');}
  function resetRoundVisual(){p1.x=400;p2.x=880;p1.hp=p2.hp=100;p1.vx=p2.vx=p1.vy=p2.vy=0;p1.jump=p2.jump=0;p1.stun=p2.stun=0;p1.attack=p2.attack=null;p1.ko=p2.ko=false;}
  function keyDown(e){const relevant=[...Object.values(keys)].flat().includes(e.key)||e.code==='Space';if(relevant)e.preventDefault();if(e.repeat)return;if(e.key==='Escape'||e.key==='p'||e.key==='P'){if(mode==='playing'||mode==='paused')pauseGame();return;}if(mode!=='playing')return;for(const [a,list] of Object.entries(keys)){if(list.includes(e.key)||list.includes(e.code)){if(['punch','kick','aura','jump'].includes(a))triggerAction(p1,a);else if(a==='guard')held.add('guard');else held.add(a);}}
  }
  function keyUp(e){for(const [a,list]of Object.entries(keys)){if(list.includes(e.key)||list.includes(e.code)){held.delete(a);if(a==='guard')held.delete('guard');}}}
  window.addEventListener('keydown',keyDown,{passive:false});window.addEventListener('keyup',keyUp);
  window.addEventListener('blur',()=>{held.clear();touchHeld.clear();if(mode==='playing')pauseGame();});
  function mobileMove(key,down,el){if(down){touchHeld.add(key);el?.classList.add('pressed');}else{touchHeld.delete(key);el?.classList.remove('pressed');}}
  document.querySelectorAll('[data-key]').forEach(btn=>{const key=btn.dataset.key;btn.addEventListener('pointerdown',e=>{e.preventDefault();btn.setPointerCapture?.(e.pointerId);mobileMove(key,true,btn);});const release=e=>{e.preventDefault?.();mobileMove(key,false,btn);};['pointerup','pointercancel','lostpointercapture'].forEach(ev=>btn.addEventListener(ev,release));});
  document.querySelectorAll('[data-action]').forEach(btn=>{const action=btn.dataset.action;btn.addEventListener('pointerdown',e=>{e.preventDefault();btn.classList.add('pressed');btn.setPointerCapture?.(e.pointerId);if(action==='guard')touchHeld.add('guard');else triggerAction(p1,action);});const release=e=>{e.preventDefault?.();btn.classList.remove('pressed');touchHeld.delete('guard');};['pointerup','pointercancel','lostpointercapture'].forEach(ev=>btn.addEventListener(ev,release));});
  $('fight-button').addEventListener('click',()=>initMatch(false));$('training-button').addEventListener('click',()=>initMatch(true));$('pause-button').addEventListener('click',pauseGame);$('resume-button').addEventListener('click',pauseGame);$('restart-button').addEventListener('click',()=>initMatch(training));$('menu-button').addEventListener('click',toMenu);$('rematch-button').addEventListener('click',()=>initMatch(false));$('result-menu-button').addEventListener('click',toMenu);$('sound-button').addEventListener('click',()=>{muted=!muted;$('sound-button').textContent=muted?'♩':'♫';$('sound-button').style.color=muted?'#7182a6':'var(--blue)';if(!muted)playTone(520,.06,'sine',.02);});
  function isHeld(k){return held.has(k)||touchHeld.has(k);}
  function triggerAction(f,action){if(mode!=='playing'||f.ko||f.stun>.22||f.hitStop>0)return;if(action==='jump'){if(f.jump<1&&f.vy>=0){f.vy=-625;f.jump=1;f.landSlam=false;playTone(255,.07,'triangle',.015);}return;}if(action==='guard'){f.guard=true;return;}if(f.attack&&f.attack.time<f.attack.duration*.78)return;if(action==='punch'||action==='kick'){const duration=action==='punch'?.32:.48;f.attack={type:action,time:0,duration,hit:false};f.guard=false;f.lastAction=action;playTone(action==='punch'?260:145,.07,'triangle',.025);return;}if(action==='aura'&&f.energy>=35&&f.specialCooldown<=0){f.energy-=35;f.attack={type:'aura',time:0,duration:.6,hit:true};f.guard=false;f.specialCooldown=1.45;projectiles.push({owner:f,x:f.x+f.facing*38,y:baseY(f)-95-f.vy*.08,z:f.z,vx:f.facing*630,life:1.55,r:27,hit:false,color:f.aura});spawnBurst(f.x+f.facing*35,baseY(f)-100,f.aura,16);playTone(340,.28,'sawtooth',.035);f.superGlow=.65;return;}}
  function baseY(f){return 508+f.z*88;}
  function updateFighter(f,dt){
    f.invuln=Math.max(0,f.invuln-dt);f.stun=Math.max(0,f.stun-dt);f.flash=Math.max(0,f.flash-dt);f.hitStop=Math.max(0,f.hitStop-dt);f.superGlow=Math.max(0,f.superGlow-dt);f.specialCooldown=Math.max(0,f.specialCooldown-dt);
    f.facing=f.player?(Math.sign(p2.x-f.x)||1):(Math.sign(p1.x-f.x)||-1);
    if(f.attack){f.attack.time+=dt;if(f.attack.time>f.attack.duration)f.attack=null;}
    if(f.player)f.guard=isHeld('guard');
    if(f.stun>0||f.ko){f.vx*=Math.pow(.025,dt);f.x+=f.vx*dt;f.energy=Math.min(100,f.energy+1.2*dt);return;}
    let dx=0,dz=0;
    if(f.player){
      dx=(isHeld('right')?1:0)-(isHeld('left')?1:0);dz=(isHeld('down')?1:0)-(isHeld('up')?1:0);
      if(Math.abs(dx)+Math.abs(dz)>0){f.walk+=dt*11;f.vx=dx*300;f.z+=dz*dt*1.05;}else{f.vx*=Math.pow(.001,dt);f.walk*=Math.max(0,1-dt*2.4);}
    }else{
      const xDist=p1.x-f.x,zDist=p1.z-f.z,ax=Math.abs(xDist),inRange=ax<190&&Math.abs(zDist)<.34;
      f.aiThink-=dt;
      if(training){
        f.guard=false;f.aiAction=0;
        if(ax>155)f.vx=Math.sign(xDist)*175;else f.vx*=Math.pow(.01,dt);
        if(Math.abs(zDist)>.12)f.z+=Math.sign(zDist)*dt*.48;
      }else{
        if(f.aiAction==='guard'&&f.aiThink>0){f.guard=true;f.vx*=Math.pow(.02,dt);}
        else{
          f.guard=false;
          if(ax>138)f.vx=Math.sign(xDist)*225;else f.vx*=Math.pow(.001,dt);
          if(Math.abs(zDist)>.11)f.z+=Math.sign(zDist)*dt*.55;
          if(f.aiThink<=0){
            if(inRange){
              const r=Math.random();
              if(p1.attack&&Math.random()<.34){f.aiAction='guard';f.guard=true;f.aiThink=.26+Math.random()*.16;}
              else if(f.energy>=35&&ax>150&&r<.2){triggerAction(f,'aura');f.aiAction=0;f.aiThink=.8+Math.random()*.3;}
              else{triggerAction(f,r<.54?'punch':'kick');f.aiAction=0;f.aiThink=.43+Math.random()*.38;}
            }else{f.aiAction=0;f.aiThink=.13+Math.random()*.16;}
          }
        }
      }
      f.walk+=Math.abs(f.vx)*dt*.035;
    }
    f.x+=f.vx*dt;f.z=Math.max(-.78,Math.min(.78,f.z));f.x=Math.max(90,Math.min(1190,f.x));
    f.energy=Math.min(100,f.energy+(f.attack?0:3.2)*dt);
  }
  function updateBody(f,dt){if(f.stun>0)return; if(f.attack&&f.attack.type!=='aura'&&!f.attack.hit){const a=f.attack,t=a.time/a.duration,hitAt=a.type==='punch'?.38:.43;if(t>=hitAt){a.hit=true;const target=f.player?p2:p1;const dx=target.x-f.x;const close=Math.abs(dx)<(a.type==='punch'?154:178)&&Math.abs(target.z-f.z)<.33&&dx*f.facing>-18;if(close&&!target.ko){dealDamage(f,target,a.type==='punch'?8:12,a.type);}}} }
  function dealDamage(attacker,target,damage,type){if(target.invuln>0)return;const blocked=target.guard;const dealt=blocked?Math.max(1,Math.round(damage*.22)):damage;target.hp=Math.max(0,target.hp-dealt);target.roundDamage+=dealt;target.flash=.13;target.invuln=.08;target.vx=(attacker.facing)*(blocked?90:(type==='kick'?350:250));target.stun=blocked?.08:(type==='kick'?.28:.18);target.hitStop=blocked?.025:.06;if(!blocked){target.airY=Math.min(target.airY||0,-38);target.vy=Math.min(target.vy||0,-80);}else{spawnBurst(target.x,targetBase(target)-75,'#b6d6ff',5);}attacker.energy=Math.min(100,attacker.energy+ (blocked?3:10));if(attacker.player){combo++;comboTimer=2.2;}shake=blocked?2:5;flash=blocked?.025:.06;spawnBurst(target.x,targetBase(target)-65,blocked?'#a9d3ff':attacker.aura,blocked?6:11);playTone(blocked?125:(type==='kick'?105:190),blocked?.055:.09,blocked?'square':'sawtooth',blocked?.02:.04);if(target.hp<=0&&!target.ko){target.ko=true;target.stun=1.5;target.vx=attacker.facing*430;spawnBurst(target.x,targetBase(target)-65,target.aura,30);}}
  function targetBase(f){return baseY(f)-(f.airY||0);}
  function spawnBurst(x,y,color,count=14){for(let i=0;i<count;i++){const a=Math.random()*TAU,s=60+Math.random()*300;particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:.25+Math.random()*.5,max:.75,size:1.5+Math.random()*4,color});}}
  function update(dt){elapsed+=dt;if(announcerTimer>0){announcerTimer-=dt;if(announcerTimer<=0)hideAnnouncement();}if(mode==='roundbreak'){roundPause-=dt;if(roundPause<=0&&playerWins<2&&cpuWins<2){mode='playing';resetRoundVisual();}return;}if(mode!=='playing')return;if(comboTimer>0){comboTimer-=dt;if(comboTimer<=0)combo=0;}if(announceHold>0)announceHold-=dt;gameTime-=dt;if(gameTime<=0){gameTime=0;nextRound(p1.hp>=p2.hp?'player':'cpu');return;}if(!p1.ko)updateFighter(p1,dt);else updateFighter(p1,dt);if(!p2.ko)updateFighter(p2,dt);else updateFighter(p2,dt);if(p1.attack)updateBody(p1,dt);if(p2.attack)updateBody(p2,dt);updateProjectiles(dt);updateEffects(dt);updateParticles(dt);shake=Math.max(0,shake-dt*22);flash=Math.max(0,flash-dt);if((p1.ko||p1.hp<=0)&&!p1.roundDone){p1.roundDone=true;nextRound('cpu');}if((p2.ko||p2.hp<=0)&&!p2.roundDone){p2.roundDone=true;nextRound('player');}syncHud();}
  function updateProjectiles(dt){for(let i=projectiles.length-1;i>=0;i--){const b=projectiles[i];b.x+=b.vx*dt;b.life-=dt;if(!b.hit){const t=b.owner.player?p2:p1;if(Math.abs(t.x-b.x)<52&&Math.abs(t.z-b.z)<.36&&Math.abs((t.x-b.owner.x))<800&&!t.ko){b.hit=true;dealDamage(b.owner,t,22,'aura');spawnBurst(b.x,b.y,b.color,23);b.life=0;}}if(b.life<=0||b.x<-40||b.x>1320)projectiles.splice(i,1);}}
  function updateEffects(dt){for(let i=effects.length-1;i>=0;i--){effects[i].life-=dt;if(effects[i].life<=0)effects.splice(i,1);}}
  function updateParticles(dt){for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.pow(.15,dt);p.vy=p.vy* Math.pow(.2,dt)+180*dt;if(p.life<=0)particles.splice(i,1);}}
  function syncHud(){ui.playerHealth.style.width=`${p1.hp}%`;ui.cpuHealth.style.width=`${p2.hp}%`;ui.playerHp.textContent=`${Math.ceil(p1.hp)} / 100`;ui.cpuHp.textContent=`${Math.ceil(p2.hp)} / 100`;ui.playerEnergy.style.width=`${p1.energy}%`;ui.cpuEnergy.style.width=`${p2.energy}%`;ui.playerEnergyText.textContent=`${Math.floor(p1.energy)}%`;ui.cpuEnergyText.textContent=`${Math.floor(p2.energy)}%`;const s=Math.max(0,gameTime);ui.timer.innerHTML=`${Math.floor(s).toString().padStart(2,'0')}<span>.${Math.floor((s%1)*100).toString().padStart(2,'0')}</span>`;}
  function draw(){ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,cw,ch);ctx.fillStyle='#050812';ctx.fillRect(0,0,cw,ch);ctx.setTransform(dpr*viewScale,0,0,dpr*viewScale,dpr*offX,dpr*offY);if(shake>0){ctx.translate((Math.random()-.5)*shake,(Math.random()-.5)*shake);}drawBackground();drawArena();const fighters=[p1,p2].sort((a,b)=>a.z-b.z);for(const f of fighters)drawFighter(f);drawProjectiles();drawParticles();drawCombatText();if(flash>0){ctx.fillStyle=`rgba(119,187,255,${flash*.4})`;ctx.fillRect(0,0,W,H);}if(mode==='menu')drawMenuOrnaments();}
  function drawBackground(){const grad=ctx.createLinearGradient(0,0,0,H);grad.addColorStop(0,'#090e22');grad.addColorStop(.46,'#17234a');grad.addColorStop(1,'#080b17');ctx.fillStyle=grad;ctx.fillRect(0,0,W,H);
    const glow=ctx.createRadialGradient(760,285,15,760,310,510);glow.addColorStop(0,'rgba(57,145,255,.19)');glow.addColorStop(.5,'rgba(37,72,158,.08)');glow.addColorStop(1,'rgba(10,16,40,0)');ctx.fillStyle=glow;ctx.fillRect(0,0,W,H);
    // distant futuristic citadel silhouettes
    for(let i=0;i<27;i++){const x=i*53-15,w=21+seededNoise(i+30)*40,h=65+seededNoise(i+11)*185,y=425-h;ctx.fillStyle=i%3===0?'rgba(36,60,117,.32)':'rgba(12,22,54,.68)';ctx.beginPath();ctx.moveTo(x,y+12);ctx.lineTo(x+w*.22,y);ctx.lineTo(x+w*.32,y+8);ctx.lineTo(x+w*.42,y-12);ctx.lineTo(x+w*.55,y+2);ctx.lineTo(x+w*.7,y+7);ctx.lineTo(x+w,y+18);ctx.lineTo(x+w,445);ctx.lineTo(x,445);ctx.closePath();ctx.fill();if(i%4===0){ctx.fillStyle='rgba(71,197,255,.45)';ctx.fillRect(x+w*.45,y+30,2,36);}}
    // energy arches in the sky
    for(let i=0;i<6;i++){ctx.strokeStyle=`rgba(60,139,255,${.055-i*.005})`;ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(660,417,230+i*53,145+i*34,-.08,Math.PI,TAU);ctx.stroke();}
    // drifting sparks
    for(let i=0;i<48;i++){const x=(seededNoise(i+9)*W+elapsed*(i%2?5:-3)+W)%W;const y=95+seededNoise(i+70)*370;ctx.fillStyle=`rgba(96,193,255,${.15+seededNoise(i+80)*.35})`;ctx.fillRect(x,y,1.5,1.5);}
  }
  function drawArena(){// perspective floor trapezoid
    ctx.beginPath();ctx.moveTo(180,414);ctx.lineTo(1100,414);ctx.lineTo(1435,690);ctx.lineTo(-155,690);ctx.closePath();const g=ctx.createLinearGradient(0,415,0,690);g.addColorStop(0,'#111d3d');g.addColorStop(.45,'#0a122a');g.addColorStop(1,'#060914');ctx.fillStyle=g;ctx.fill();ctx.strokeStyle='rgba(72,170,255,.6)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(180,414);ctx.lineTo(1100,414);ctx.stroke();ctx.strokeStyle='rgba(58,128,230,.22)';ctx.lineWidth=1;
    const floorY=414;for(let i=0;i<=12;i++){const t=i/12;const y=floorY+Math.pow(t,1.7)*276;ctx.beginPath();ctx.moveTo(-160+(t*335),y);ctx.lineTo(1440-(t*335),y);ctx.stroke();}for(let i=-6;i<=6;i++){ctx.beginPath();ctx.moveTo(640+i*42,414);ctx.lineTo(640+i*105,690);ctx.stroke();}
    // glowing central insignia
    ctx.save();ctx.globalAlpha=.22;ctx.strokeStyle='#42cfff';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(640,540,154,33,0,0,TAU);ctx.stroke();ctx.beginPath();ctx.ellipse(640,540,96,20,0,0,TAU);ctx.stroke();ctx.beginPath();ctx.moveTo(640,513);ctx.lineTo(640,563);ctx.moveTo(610,538);ctx.lineTo(670,538);ctx.stroke();ctx.restore();
    // runway lights
    for(let side of [-1,1])for(let i=0;i<13;i++){const t=i/13,y=432+t*240,x=640+side*(440+t*350);ctx.fillStyle=`rgba(67,183,255,${.5*(1-t)+.08})`;ctx.fillRect(x,y,2+t*1.8,2+t*1.4);}
  }
  function projected(f){const scale=.78+(f.z+.8)*.14;return {x:f.x,y:baseY(f),scale};}
  function drawFighter(f){const pr=projected(f),sc=pr.scale,ground=pr.y,air=(f.airY||0)+(f.fallY||0),x=f.x,y=ground+air;const attacking=f.attack,atk=attacking?Math.min(1,attacking.time/attacking.duration):0;let pose=attacking?attacking.type:(f.guard?'guard':'idle');const bob=f.jump?0:Math.sin(f.walk)*2*sc;const h=117*sc;const shadowY=ground+4+(f.airY||0)*-.03;
    // ground shadow
    ctx.save();ctx.translate(x,shadowY);ctx.scale(sc,sc);ctx.fillStyle=`rgba(0,0,0,${Math.max(.12,.34+air/700)})`;ctx.beginPath();ctx.ellipse(0,0,36+Math.abs(air)*.035,8,0,0,TAU);ctx.fill();ctx.restore();
    // aura pulse
    if(f.energy>25||f.superGlow>0){ctx.save();const a=.06+(f.energy/100)*.11+f.superGlow*.28;const rr=(48+Math.sin(elapsed*5+(f.player?0:2))*5+f.superGlow*55)*sc;const glow=ctx.createRadialGradient(x,y-58*sc,3,x,y-58*sc,rr);glow.addColorStop(0,`${f.aura}${Math.round(Math.min(.38,a)*255).toString(16).padStart(2,'0')}`);glow.addColorStop(1,`${f.aura}00`);ctx.fillStyle=glow;ctx.beginPath();ctx.ellipse(x,y-58*sc,rr,rr*1.45,0,0,TAU);ctx.fill();ctx.restore();}
    // persona aura sparks
    if(f.superGlow>0){ctx.save();ctx.globalAlpha=f.superGlow;ctx.strokeStyle=f.aura;ctx.lineWidth=2;for(let i=0;i<4;i++){const a=elapsed*6+i*TAU/4;ctx.beginPath();ctx.arc(x,y-58*sc,30*sc+i*5*sc,a,a+1.25);ctx.stroke();}ctx.restore();}
    ctx.save();ctx.translate(x,y);ctx.scale(sc,sc);ctx.lineCap='round';ctx.lineJoin='round';if(f.facing<0)ctx.scale(-1,1);if(f.flash>0){ctx.shadowColor='#fff';ctx.shadowBlur=20;}
    // limbs and joints in pseudo-3D, using a bright edge and darker core
    const line=(pts,width,color)=>{ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.lineWidth=width+2;ctx.strokeStyle=f.player?'rgba(36,73,106,.9)':'rgba(94,32,68,.9)';ctx.stroke();ctx.lineWidth=width;ctx.strokeStyle=color;ctx.stroke();};
    const cyan=f.flash>0?'#fff':f.color;const aura=f.aura;const idleSwing=Math.sin(f.walk)*8;let armFront=[24,-66,38,-48,43,-30],armBack=[-20,-66,-30,-47,-24,-30],legFront=[10,-29,17,-13,24,0],legBack=[-8,-29,-19,-14,-23,0];
    if(f.jump||air<0){legFront=[10,-29,22,-10,32,-12];legBack=[-8,-29,-18,-7,-10,-2];armFront=[24,-66,36,-84,43,-91];armBack=[-20,-66,-38,-54,-42,-45];}
    else if(pose==='punch'){const reach=Math.sin(Math.min(1,atk*1.35)*Math.PI/2);armFront=[22,-67,33+32*reach,-65,40+53*reach,-63+((atk>.35&&atk<.65)?-4:0)];armBack=[-20,-65,-31,-47,-25,-33];legFront=[9,-28,17,-12,23,-1];}
    else if(pose==='kick'){const kick= Math.sin(Math.min(1,atk*1.35)*Math.PI/2);legFront=[10,-29,32+15*kick,-17,38+54*kick,-9-28*kick];armFront=[22,-66,32,-54,35,-46];armBack=[-20,-66,-31,-49,-27,-39];}
    else if(pose==='guard'){armFront=[22,-67,32,-78,12,-80];armBack=[-20,-66,-28,-76,-5,-77];legFront=[10,-29,16,-13,21,-1];}
    else{armFront=[22,-66,29+idleSwing*.5,-48,35+idleSwing*.65,-29];armBack=[-20,-66,-29-idleSwing*.4,-46,-25-idleSwing*.7,-31];legFront=[10,-29,17+idleSwing*.18,-13,23+idleSwing*.25,0];legBack=[-8,-29,-17-idleSwing*.2,-13,-22-idleSwing*.3,0];}
    // aura trails behind moving fighter
    if(Math.abs(f.vx)>60&&!f.guard){ctx.globalAlpha=.14;ctx.strokeStyle=aura;ctx.lineWidth=11;ctx.beginPath();ctx.moveTo(-f.facing*5,-49);ctx.lineTo(-f.facing*(23+Math.abs(f.vx)*.06),-48);ctx.stroke();ctx.globalAlpha=1;}
    line([[0,-60],[2,-34],[0,-29]],9,cyan); // torso spine
    // hips
    ctx.fillStyle=cyan;ctx.beginPath();ctx.ellipse(0,-29,10,6,.08,0,TAU);ctx.fill();
    line([[legBack[0],legBack[1]],[legBack[2],legBack[3]],[legBack[4],legBack[5]]],7,cyan);
    line([[legFront[0],legFront[1]],[legFront[2],legFront[3]],[legFront[4],legFront[5]]],7,cyan);
    line([[armBack[0],armBack[1]],[armBack[2],armBack[3]],[armBack[4],armBack[5]]],7,cyan);
    line([[armFront[0],armFront[1]],[armFront[2],armFront[3]],[armFront[4],armFront[5]]],8,cyan);
    // joints light beads
    [[armFront[2],armFront[3]],[armFront[4],armFront[5]],[legFront[2],legFront[3]],[legFront[4],legFront[5]],[-8,-29],[2,-34]].forEach((q,i)=>{ctx.fillStyle=i%2===0?aura:cyan;ctx.shadowColor=aura;ctx.shadowBlur=i===1?10:3;ctx.beginPath();ctx.arc(q[0],q[1],i===1?4:3,0,TAU);ctx.fill();});ctx.shadowBlur=0;
    // head: bright halo + dark face plate
    ctx.fillStyle=aura;ctx.globalAlpha=.2;ctx.beginPath();ctx.arc(0,-82,20,0,TAU);ctx.fill();ctx.globalAlpha=1;ctx.fillStyle=cyan;ctx.beginPath();ctx.arc(0,-82,13,0,TAU);ctx.fill();ctx.fillStyle='#0a142a';ctx.beginPath();ctx.ellipse(3,-81,8,8,-.1,0,TAU);ctx.fill();ctx.strokeStyle=aura;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(1,-84);ctx.lineTo(10,-84);ctx.stroke();
    // energy streaks when attack is active
    if(attacking&&attacking.type!=='aura'){const power=Math.sin(Math.min(1,atk)*Math.PI);ctx.globalAlpha=.25+power*.55;ctx.strokeStyle=aura;ctx.lineWidth=4;ctx.beginPath();if(attacking.type==='punch'){ctx.arc(49,-63,28,-.9,.6);}else{ctx.arc(35,-18,47,-.3,.55);}ctx.stroke();ctx.globalAlpha=1;}
    if(f.guard){ctx.globalAlpha=.42;ctx.strokeStyle=aura;ctx.lineWidth=3;ctx.beginPath();ctx.arc(7,-52,46,-1.25,1.15);ctx.stroke();ctx.globalAlpha=1;}
    ctx.restore();
    // character label and shadowed aura bar marker
    ctx.save();ctx.textAlign='center';ctx.font=`700 ${10*sc}px Orbitron, sans-serif`;ctx.fillStyle=f.player?'#a7eeff':'#ffb1d5';ctx.globalAlpha=.92;ctx.fillText(f.name,x,ground+26);ctx.restore();
    if(f.ko&&f.fallY>10){ctx.save();ctx.globalAlpha=.45;ctx.fillStyle='#050711';ctx.beginPath();ctx.ellipse(x,ground+9,42,8,0,0,TAU);ctx.fill();ctx.restore();}
  }
  function drawProjectiles(){for(const b of projectiles){ctx.save();ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(b.x,b.y,2,b.x,b.y,b.r*1.7);g.addColorStop(0,'#fff');g.addColorStop(.15,b.color);g.addColorStop(1,`${b.color}00`);ctx.fillStyle=g;ctx.beginPath();ctx.arc(b.x,b.y,b.r*1.7,0,TAU);ctx.fill();ctx.fillStyle=b.color;ctx.beginPath();ctx.ellipse(b.x,b.y,b.r*1.15,b.r*.78,0,0,TAU);ctx.fill();ctx.globalAlpha=.7;ctx.strokeStyle=b.color;ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(b.x-b.vx*.085,b.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.restore();}}
  function drawParticles(){ctx.save();ctx.globalCompositeOperation='lighter';for(const p of particles){ctx.globalAlpha=Math.min(1,p.life*2);ctx.fillStyle=p.color;ctx.shadowColor=p.color;ctx.shadowBlur=8;ctx.fillRect(p.x,p.y,p.size,p.size);}ctx.restore();}
  function drawCombatText(){if(combo>=2&&comboTimer>0&&mode==='playing'){ctx.save();ctx.textAlign='center';ctx.font='800 20px Orbitron, sans-serif';ctx.fillStyle='#6de4ff';ctx.shadowColor='#166dff';ctx.shadowBlur=20;ctx.fillText(`${combo} HIT COMBO`,260,285);ctx.restore();}if(mode==='playing'){const f=p1;if(f.energy>=35){ctx.save();ctx.textAlign='center';ctx.font='700 9px Orbitron, sans-serif';ctx.fillStyle='#a5baff';ctx.globalAlpha=.6+.3*Math.sin(elapsed*4);ctx.fillText('AURA READY  [ I ]',p1.x,baseY(p1)-150);ctx.restore();}}}
  function drawMenuOrnaments(){ctx.save();ctx.globalCompositeOperation='lighter';const x=930,y=410;const pulse=1+Math.sin(elapsed*1.6)*.035;const radius=120*pulse;const aura=ctx.createRadialGradient(x,y,5,x,y,radius*2.2);aura.addColorStop(0,'rgba(45,174,255,.19)');aura.addColorStop(.6,'rgba(47,91,255,.06)');aura.addColorStop(1,'rgba(44,104,255,0)');ctx.fillStyle=aura;ctx.beginPath();ctx.arc(x,y,radius*2.2,0,TAU);ctx.fill();for(let i=0;i<5;i++){const rr=radius+i*19;ctx.strokeStyle=`rgba(60,173,255,${.15-i*.022})`;ctx.lineWidth=1.2;ctx.beginPath();ctx.ellipse(x,y,rr,rr*1.48,Math.sin(elapsed*.2)*.08,elapsed*.16+i,elapsed*.16+i+Math.PI*1.45);ctx.stroke();}ctx.restore();}
  function loop(now){const dt=Math.min(.032,(now-last)/1000||0);last=now;if(mode==='playing'||mode==='roundbreak')update(dt);else{elapsed+=dt;if(announcerTimer>0){announcerTimer-=dt;if(announcerTimer<=0)hideAnnouncement();}updateParticles(dt);updateEffects(dt);}draw();requestAnimationFrame(loop);}
  // Correct a character's vertical motion after creation and after a hit.
  function normalizeFighter(f){f.airY=f.airY||0;f.vy=f.vy||0;f.fallY=f.fallY||0;f.yVel=f.yVel||0;f.air=0;f.roundDone=false;}
  normalizeFighter(p1);normalizeFighter(p2);
  const originalInit=initMatch;
  initMatch=function(isTraining=false){originalInit(isTraining);normalizeFighter(p1);normalizeFighter(p2);p1.roundDone=p2.roundDone=false;};
  // Wrap vertical motion in a dedicated pass; keeping height separate from lane depth makes it a 2.5D fighter.
  const previousUpdate=update;
  update=function(dt){
    previousUpdate(dt);
    if(mode==='playing')for(const f of [p1,p2]){
      if(f.vy!==0||(f.airY||0)<0){f.vy+=1550*dt;f.airY=(f.airY||0)+f.vy*dt;if(f.airY>=0){f.airY=0;f.vy=0;f.jump=0;}}
    }
  };
  resize();
  // The rendering/update loop always continues; game simulation only advances while active.
  last=performance.now();requestAnimationFrame(loop);
})();
