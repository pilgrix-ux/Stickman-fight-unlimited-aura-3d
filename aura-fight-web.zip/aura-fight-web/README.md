# Unlimited Aura — 2.5D Arena Fighter

A mobile-first, browser-playable 2.5D stickman fighting game. The arena, fighters, neon effects and particle bursts are drawn procedurally, so there are no large art assets or build dependencies.

## Run locally

Open `index.html` in a modern browser, or use a small local web server:

```bash
python -m http.server 8080
```

Then visit `http://localhost:8080`.

## Controls

- **Move:** A / D or ← / →
- **Move in/out of the arena lane:** W / S or ↑ / ↓
- **Jump:** Space
- **Punch:** J
- **Kick:** K
- **Guard:** hold L
- **Aura blast:** I (uses 35 aura)
- **Pause:** Escape or P

On mobile, use the on-screen movement pad and action buttons. Landscape orientation is recommended; the browser may ask to rotate the device.

## Deploy to GitHub Pages

1. Extract the project ZIP.
2. Upload `index.html`, `style.css`, `game.js`, and `README.md` to the root of `pilgrix-ux/Stickman-fight-unlimited-aura-3d`.
3. In GitHub, open **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Open the Pages URL once GitHub finishes deployment.

This is a playable prototype foundation. It uses plain HTML, CSS and JavaScript, with no framework or package-install step. Google Fonts are optional network-loaded typography; gameplay itself has no external library dependency.
